#ifndef __XUNJI_H__
#define __XUNJI_H__
void lefthand_xunji(uint8_t data);
void memory_xunji(uint8_t data);
void simply(void);
void xunji(uint8_t);
extern char arr[256];
extern char*p;
extern int i;
extern int k;
#endif //__XUNJI_H__
